import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHmac, createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';

const root = dirname(fileURLToPath(import.meta.url));
const port = numberEnv('PORT', 3000, 1, 65535);
const databasePath = process.env.DB_PATH || join(root, 'data', 'bloodline-staff.sqlite');
const apiKey = requiredSecret('API_KEY', 24);
const staffPassword = requiredSecret('STAFF_PASSWORD', 12);
const sessionSecret = requiredSecret('SESSION_SECRET', 32);
const sessionHours = numberEnv('SESSION_HOURS', 12, 1, 168);
const production = process.env.NODE_ENV === 'production';

const database = new DatabaseSync(databasePath);
database.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA synchronous = NORMAL;
  PRAGMA busy_timeout = 5000;
  CREATE TABLE IF NOT EXISTS cases (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL CHECK(type IN ('BAN','MUTE','KICK','WARN')),
    target_uuid TEXT NOT NULL,
    target_name TEXT NOT NULL,
    actor_uuid TEXT,
    actor_name TEXT NOT NULL,
    reason TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    expires_at INTEGER,
    status TEXT NOT NULL CHECK(status IN ('ACTIVE','COMPLETED','REVOKED','EXPIRED')),
    revoked_by TEXT,
    revoked_at INTEGER,
    revoke_reason TEXT,
    updated_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_cases_target ON cases(target_name COLLATE NOCASE, created_at DESC);
  CREATE INDEX IF NOT EXISTS idx_cases_actor ON cases(actor_name COLLATE NOCASE, created_at DESC);
  CREATE INDEX IF NOT EXISTS idx_cases_status ON cases(status, type, created_at DESC);
`);

const upsertCase = database.prepare(`
  INSERT INTO cases (id, type, target_uuid, target_name, actor_uuid, actor_name, reason,
    created_at, expires_at, status, revoked_by, revoked_at, revoke_reason, updated_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  ON CONFLICT(id) DO UPDATE SET
    type=excluded.type, target_uuid=excluded.target_uuid, target_name=excluded.target_name,
    actor_uuid=excluded.actor_uuid, actor_name=excluded.actor_name, reason=excluded.reason,
    created_at=excluded.created_at, expires_at=excluded.expires_at, status=excluded.status,
    revoked_by=excluded.revoked_by, revoked_at=excluded.revoked_at,
    revoke_reason=excluded.revoke_reason, updated_at=excluded.updated_at
`);
const publicCase = database.prepare(`
  SELECT id, type, target_name, actor_name, reason, created_at, expires_at, status,
         revoked_by, revoked_at, revoke_reason
  FROM cases WHERE id = ?
`);

const limits = new Map();
setInterval(() => {
  const now = Date.now();
  for (const [key, value] of limits) if (value.resetAt <= now) limits.delete(key);
}, 60_000).unref();

const server = createServer(async (request, response) => {
  try {
    securityHeaders(response);
    const url = new URL(request.url || '/', 'http://local');
    const ip = clientIp(request);

    if (request.method === 'GET' && url.pathname === '/health') return json(response, 200, { ok: true });

    if (request.method === 'POST' && url.pathname === '/api/v1/cases') {
      if (!bearerAuthorized(request)) return json(response, 401, { error: 'Unauthorized' });
      const value = validateCase(await readJson(request));
      upsertCase.run(value.id, value.type, value.targetUuid, value.targetName, value.actorUuid,
        value.actorName, value.reason, value.createdAt, value.expiresAt, value.status,
        value.revokedBy, value.revokedAt, value.revokeReason, Date.now());
      return json(response, 200, { ok: true, id: value.id });
    }

    if (request.method === 'GET' && url.pathname.startsWith('/api/public/cases/')) {
      if (!allow(`lookup:${ip}`, 120, 60_000)) return json(response, 429, { error: 'Too many requests' });
      const id = decodeURIComponent(url.pathname.slice('/api/public/cases/'.length)).toUpperCase();
      if (!caseId(id)) return json(response, 400, { error: 'Invalid Ban ID' });
      const row = publicCase.get(id);
      return row ? json(response, 200, publicView(row)) : json(response, 404, { error: 'Ban ID not found' });
    }

    if (request.method === 'POST' && url.pathname === '/api/auth/login') {
      if (!allow(`login:${ip}`, 5, 15 * 60_000)) return json(response, 429, { error: 'Too many login attempts' });
      const body = await readJson(request);
      if (!safeEqual(String(body.password || ''), staffPassword)) return json(response, 401, { error: 'Incorrect password' });
      const cookie = createSession();
      response.setHeader('Set-Cookie', `bloodline_session=${cookie}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${sessionHours * 3600}${production ? '; Secure' : ''}`);
      return json(response, 200, { ok: true });
    }

    if (request.method === 'POST' && url.pathname === '/api/auth/logout') {
      response.setHeader('Set-Cookie', `bloodline_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${production ? '; Secure' : ''}`);
      return json(response, 200, { ok: true });
    }

    if (request.method === 'GET' && url.pathname === '/api/auth/session') {
      return sessionAuthorized(request) ? json(response, 200, { authenticated: true }) : json(response, 401, { authenticated: false });
    }

    if (request.method === 'GET' && url.pathname === '/api/staff/cases') {
      if (!sessionAuthorized(request)) return json(response, 401, { error: 'Unauthorized' });
      return json(response, 200, listCases(url.searchParams));
    }

    if (request.method === 'GET' && url.pathname === '/api/staff/stats') {
      if (!sessionAuthorized(request)) return json(response, 401, { error: 'Unauthorized' });
      const row = database.prepare(`
        SELECT COUNT(*) total,
          SUM(CASE WHEN type='BAN' AND status='ACTIVE' THEN 1 ELSE 0 END) active_bans,
          SUM(CASE WHEN type='MUTE' AND status='ACTIVE' THEN 1 ELSE 0 END) active_mutes,
          SUM(CASE WHEN created_at >= ? THEN 1 ELSE 0 END) cases_today
        FROM cases
      `).get(Date.now() - 86_400_000);
      return json(response, 200, row);
    }

    if (request.method === 'GET') return staticFile(url.pathname, response);
    return json(response, 404, { error: 'Not found' });
  } catch (error) {
    const status = error?.statusCode || 500;
    if (status === 500) console.error(error);
    return json(response, status, { error: status === 500 ? 'Internal server error' : error.message });
  }
});

server.listen(port, '0.0.0.0', () => console.log(`Bloodline Staff Portal listening on ${port}`));

function listCases(params) {
  const query = String(params.get('q') || '').trim().slice(0, 100);
  const type = String(params.get('type') || '').toUpperCase();
  const status = String(params.get('status') || '').toUpperCase();
  const page = Math.max(1, Math.min(10000, Number.parseInt(params.get('page') || '1', 10) || 1));
  const where = [];
  const values = [];
  if (query) {
    where.push('(id LIKE ? OR target_name LIKE ? OR actor_name LIKE ? OR reason LIKE ?)');
    for (let index = 0; index < 4; index++) values.push(`%${query}%`);
  }
  if (['BAN', 'MUTE', 'KICK', 'WARN'].includes(type)) { where.push('type = ?'); values.push(type); }
  if (['ACTIVE', 'COMPLETED', 'REVOKED', 'EXPIRED'].includes(status)) { where.push('status = ?'); values.push(status); }
  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = database.prepare(`SELECT COUNT(*) count FROM cases ${clause}`).get(...values).count;
  const rows = database.prepare(`
    SELECT id, type, target_name, actor_name, reason, created_at, expires_at, status,
           revoked_by, revoked_at, revoke_reason
    FROM cases ${clause} ORDER BY created_at DESC LIMIT 25 OFFSET ?
  `).all(...values, (page - 1) * 25).map(publicView);
  return { cases: rows, total, page, pages: Math.max(1, Math.ceil(total / 25)) };
}

function validateCase(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) bad('Invalid body');
  const value = {
    id: text(input.id, 32).toUpperCase(),
    type: text(input.type, 8).toUpperCase(),
    targetUuid: text(input.targetUuid, 36),
    targetName: text(input.targetName, 16),
    actorUuid: input.actorUuid == null ? null : text(input.actorUuid, 36),
    actorName: text(input.actorName, 32),
    reason: text(input.reason, 500),
    createdAt: integer(input.createdAt),
    expiresAt: input.expiresAt == null ? null : integer(input.expiresAt),
    status: text(input.status, 12).toUpperCase(),
    revokedBy: input.revokedBy == null ? null : text(input.revokedBy, 32),
    revokedAt: input.revokedAt == null ? null : integer(input.revokedAt),
    revokeReason: input.revokeReason == null ? null : text(input.revokeReason, 500)
  };
  if (!caseId(value.id)) bad('Invalid case ID');
  if (!['BAN', 'MUTE', 'KICK', 'WARN'].includes(value.type)) bad('Invalid type');
  if (!['ACTIVE', 'COMPLETED', 'REVOKED', 'EXPIRED'].includes(value.status)) bad('Invalid status');
  if (!uuid(value.targetUuid) || value.actorUuid != null && !uuid(value.actorUuid)) bad('Invalid UUID');
  if (value.createdAt < 1_577_836_800_000 || value.createdAt > Date.now() + 86_400_000) bad('Invalid creation time');
  if (value.expiresAt != null && value.expiresAt <= value.createdAt) bad('Invalid expiry');
  return value;
}

function publicView(row) {
  return {
    id: row.id, type: row.type, player: row.target_name, staff: row.actor_name,
    reason: row.reason, createdAt: row.created_at, expiresAt: row.expires_at,
    status: row.status, revokedBy: row.revoked_by, revokedAt: row.revoked_at,
    revokeReason: row.revoke_reason
  };
}

async function staticFile(pathname, response) {
  const files = {
    '/': ['index.html', 'text/html; charset=utf-8'],
    '/index.html': ['index.html', 'text/html; charset=utf-8'],
    '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
    '/styles.css': ['styles.css', 'text/css; charset=utf-8']
  };
  const asset = files[pathname];
  if (!asset) return json(response, 404, { error: 'Not found' });
  const body = await readFile(join(root, 'public', asset[0]));
  response.writeHead(200, { 'Content-Type': asset[1], 'Cache-Control': asset[0] === 'index.html' ? 'no-cache' : 'public, max-age=3600' });
  response.end(body);
}

async function readJson(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 32_768) { const error = new Error('Request too large'); error.statusCode = 413; throw error; }
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); }
  catch { bad('Invalid JSON'); }
}

function bearerAuthorized(request) {
  const header = request.headers.authorization || '';
  return header.startsWith('Bearer ') && safeEqual(header.slice(7), apiKey);
}

function createSession() {
  const payload = Buffer.from(JSON.stringify({ exp: Date.now() + sessionHours * 3_600_000, nonce: randomBytes(12).toString('hex') })).toString('base64url');
  return `${payload}.${sign(payload)}`;
}

function sessionAuthorized(request) {
  const cookies = Object.fromEntries(String(request.headers.cookie || '').split(';').map(value => value.trim().split('=')));
  const token = cookies.bloodline_session || '';
  const [payload, signature] = token.split('.');
  if (!payload || !signature || !safeEqual(signature, sign(payload))) return false;
  try { return Number(JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')).exp) > Date.now(); }
  catch { return false; }
}

function sign(value) { return createHmac('sha256', sessionSecret).update(value).digest('base64url'); }
function safeEqual(left, right) {
  const a = createHash('sha256').update(String(left)).digest();
  const b = createHash('sha256').update(String(right)).digest();
  return timingSafeEqual(a, b);
}
function allow(key, maximum, windowMs) {
  const now = Date.now();
  let value = limits.get(key);
  if (!value || value.resetAt <= now) value = { count: 0, resetAt: now + windowMs };
  value.count += 1;
  limits.set(key, value);
  return value.count <= maximum;
}
function clientIp(request) { return String(request.headers['x-forwarded-for'] || request.socket.remoteAddress || '').split(',')[0].trim(); }
function caseId(value) { return /^BL-\d{8}-[0-9A-HJKMNPQRSTVWXYZ]{10}$/.test(value); }
function uuid(value) { return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value); }
function text(value, maximum) { if (typeof value !== 'string' || !value.trim() || value.length > maximum) bad('Invalid text field'); return value.trim(); }
function integer(value) { if (!Number.isSafeInteger(value)) bad('Invalid number field'); return value; }
function bad(message) { const error = new Error(message); error.statusCode = 400; throw error; }
function numberEnv(name, fallback, minimum, maximum) { const value = Number.parseInt(process.env[name] || String(fallback), 10); if (value < minimum || value > maximum) throw new Error(`${name} is invalid`); return value; }
function requiredSecret(name, minimum) { const value = process.env[name] || ''; if (value.length < minimum) throw new Error(`${name} must be at least ${minimum} characters`); return value; }
function json(response, status, value) { const body = JSON.stringify(value); response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body), 'Cache-Control': 'no-store' }); response.end(body); }
function securityHeaders(response) {
  response.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.setHeader('Referrer-Policy', 'no-referrer');
  response.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  response.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
}

export { server };
