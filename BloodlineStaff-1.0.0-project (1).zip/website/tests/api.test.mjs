import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawn } from 'node:child_process';

test('plugin ingestion, public lookup and staff authentication', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'bloodline-staff-'));
  const port = 32100 + Math.floor(Math.random() * 1000);
  const apiKey = 'a'.repeat(64);
  const password = 'correct horse battery staple';
  const child = spawn(process.execPath, ['server.mjs'], {
    cwd: new URL('..', import.meta.url),
    env: { ...process.env, PORT: String(port), NODE_ENV: 'test', DB_PATH: join(directory, 'test.sqlite'), API_KEY: apiKey, STAFF_PASSWORD: password, SESSION_SECRET: 's'.repeat(64) },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  try {
    await waitForServer(child, port);
    const origin = `http://127.0.0.1:${port}`;
    const value = { id: 'BL-20260926-AB12CD34EF', type: 'BAN', targetUuid: '123e4567-e89b-42d3-a456-426614174000', targetName: 'TestPlayer', actorUuid: null, actorName: 'Console', reason: 'Cheating', createdAt: Date.now(), expiresAt: null, status: 'ACTIVE', revokedBy: null, revokedAt: null, revokeReason: null };

    let response = await fetch(`${origin}/api/v1/cases`, { method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' }, body: JSON.stringify(value) });
    assert.equal(response.status, 200);
    response = await fetch(`${origin}/api/public/cases/${value.id}`);
    assert.equal(response.status, 200);
    const publicValue = await response.json();
    assert.equal(publicValue.player, 'TestPlayer');
    assert.equal(publicValue.targetUuid, undefined);

    response = await fetch(`${origin}/api/staff/cases`);
    assert.equal(response.status, 401);
    response = await fetch(`${origin}/api/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password }) });
    assert.equal(response.status, 200);
    const cookie = response.headers.get('set-cookie').split(';', 1)[0];
    response = await fetch(`${origin}/api/staff/cases`, { headers: { Cookie: cookie } });
    assert.equal(response.status, 200);
    assert.equal((await response.json()).total, 1);

    value.status = 'REVOKED'; value.revokedBy = 'Owner'; value.revokedAt = Date.now(); value.revokeReason = 'Appeal accepted';
    response = await fetch(`${origin}/api/v1/cases`, { method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' }, body: JSON.stringify(value) });
    assert.equal(response.status, 200);
    response = await fetch(`${origin}/api/public/cases/${value.id}`);
    assert.equal((await response.json()).status, 'REVOKED');
  } finally {
    child.kill('SIGTERM');
    await new Promise(resolve => child.once('exit', resolve));
    await rm(directory, { recursive: true, force: true });
  }
});

async function waitForServer(child, port) {
  const deadline = Date.now() + 8_000;
  while (Date.now() < deadline) {
    if (child.exitCode != null) throw new Error(`Server exited early with ${child.exitCode}`);
    try { const response = await fetch(`http://127.0.0.1:${port}/health`); if (response.ok) return; } catch { }
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  throw new Error('Server did not start');
}
