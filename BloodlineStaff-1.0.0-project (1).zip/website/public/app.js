const views = document.querySelectorAll('.view');
const navigation = document.querySelectorAll('[data-view]');
let currentPage = 1;

for (const button of navigation) button.addEventListener('click', () => showView(button.dataset.view));
document.querySelector('#lookup-form').addEventListener('submit', lookup);
document.querySelector('#login-form').addEventListener('submit', login);
document.querySelector('#filters').addEventListener('submit', event => { event.preventDefault(); currentPage = 1; loadCases(); });
document.querySelector('#logout').addEventListener('click', logout);

function showView(id) {
  for (const view of views) view.classList.toggle('active', view.id === id);
  for (const button of navigation) button.classList.toggle('active', button.dataset.view === id);
  if (id === 'staff') checkSession();
}

async function lookup(event) {
  event.preventDefault();
  const id = document.querySelector('#case-id').value.trim().toUpperCase();
  setMessage('#lookup-message', 'Checking…', false);
  document.querySelector('#lookup-result').classList.add('hidden');
  const response = await fetch(`/api/public/cases/${encodeURIComponent(id)}`);
  const value = await response.json();
  if (!response.ok) return setMessage('#lookup-message', value.error || 'Could not check that ID.', true);
  setMessage('#lookup-message', '', false);
  renderCase(value);
}

function renderCase(value) {
  const card = document.querySelector('#lookup-result');
  card.replaceChildren();
  const head = element('div', 'case-head');
  const title = element('div');
  title.append(element('span', 'badge', value.type), element('h2', '', value.player), element('div', 'case-id', value.id));
  head.append(title, element('span', `badge ${value.status.toLowerCase()}`, value.status));
  const grid = element('div', 'case-grid');
  field(grid, 'Issued by', value.staff);
  field(grid, 'Issued', date(value.createdAt));
  field(grid, 'Expires', value.expiresAt ? date(value.expiresAt) : 'Permanent');
  field(grid, 'Status', value.status);
  field(grid, 'Reason', value.reason, true);
  if (value.revokeReason) field(grid, 'Revocation', value.revokeReason, true);
  card.append(head, grid);
  card.classList.remove('hidden');
}

async function login(event) {
  event.preventDefault();
  const password = document.querySelector('#password').value;
  const response = await fetch('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password }) });
  const value = await response.json();
  if (!response.ok) return setMessage('#login-message', value.error || 'Sign-in failed.', true);
  document.querySelector('#password').value = '';
  showDashboard();
}

async function checkSession() {
  const response = await fetch('/api/auth/session');
  if (response.ok) showDashboard(); else showLogin();
}
function showDashboard() { document.querySelector('#login-panel').classList.add('hidden'); document.querySelector('#dashboard').classList.remove('hidden'); loadStats(); loadCases(); }
function showLogin() { document.querySelector('#dashboard').classList.add('hidden'); document.querySelector('#login-panel').classList.remove('hidden'); }
async function logout() { await fetch('/api/auth/logout', { method: 'POST' }); showLogin(); }

async function loadStats() {
  const response = await fetch('/api/staff/stats');
  if (response.status === 401) return showLogin();
  const value = await response.json();
  const stats = document.querySelector('#stats');
  stats.replaceChildren();
  for (const [label, count] of [['Total cases', value.total], ['Active bans', value.active_bans], ['Active mutes', value.active_mutes], ['Last 24 hours', value.cases_today]]) {
    const card = element('div', 'stat'); card.append(element('strong', '', String(count || 0)), element('span', '', label)); stats.append(card);
  }
}

async function loadCases() {
  const params = new URLSearchParams({ page: String(currentPage), q: document.querySelector('#search').value, type: document.querySelector('#type').value, status: document.querySelector('#status').value });
  const response = await fetch(`/api/staff/cases?${params}`);
  if (response.status === 401) return showLogin();
  const value = await response.json();
  if (!response.ok) return setMessage('#table-message', value.error || 'Could not load cases.', true);
  const rows = document.querySelector('#case-rows'); rows.replaceChildren();
  for (const item of value.cases) {
    const row = document.createElement('tr');
    for (const text of [item.id, item.type, item.player, item.staff, item.reason, item.status, date(item.createdAt)]) row.append(element('td', '', text));
    rows.append(row);
  }
  setMessage('#table-message', value.cases.length ? '' : 'No cases match those filters.', false);
  pagination(value.page, value.pages);
}

function pagination(page, pages) {
  const node = document.querySelector('#pagination'); node.replaceChildren();
  const previous = element('button', 'secondary', 'Previous'); previous.disabled = page <= 1; previous.addEventListener('click', () => { currentPage--; loadCases(); });
  const next = element('button', 'secondary', 'Next'); next.disabled = page >= pages; next.addEventListener('click', () => { currentPage++; loadCases(); });
  node.append(previous, element('span', '', `Page ${page} of ${pages}`), next);
}

function field(parent, label, value, wide = false) { const node = element('div', wide ? 'wide' : ''); node.append(element('small', '', label), element('span', '', value)); parent.append(node); }
function element(tag, className = '', text = '') { const node = document.createElement(tag); if (className) node.className = className; if (text) node.textContent = text; return node; }
function setMessage(selector, text, error) { const node = document.querySelector(selector); node.textContent = text; node.style.color = error ? '#ff7a7a' : '#9898a2'; }
function date(timestamp) { return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(timestamp)); }

if (location.hash === '#staff') showView('staff');
