# Third-party notices

The compiled plugin includes Google Gson 2.13.1, licensed under the Apache License 2.0.

The source bundle also contains build-only API/dependency jars for reproducible offline compilation, including Paper API, Kyori Adventure, JetBrains Annotations, BungeeCord Chat, Google Guava, SnakeYAML, and JUnit. Those files remain under their respective upstream licenses and are not claimed as BloodlineStaff source code.

- Gson: <https://github.com/google/gson>
- Paper: <https://github.com/PaperMC/Paper>
- Adventure: <https://github.com/KyoriPowered/adventure>
- JUnit: <https://junit.org/>
