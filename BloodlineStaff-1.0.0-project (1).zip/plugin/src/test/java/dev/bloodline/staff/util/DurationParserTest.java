package dev.bloodline.staff.util;

import org.junit.jupiter.api.Test;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DurationParserTest {
    @Test
    void parsesSupportedUnits() {
        assertEquals(Duration.ofMinutes(30), DurationParser.parse("30m").orElseThrow());
        assertEquals(Duration.ofDays(14), DurationParser.parse("2w").orElseThrow());
        assertEquals(Duration.ofDays(30), DurationParser.parse("1M").orElseThrow());
        assertTrue(DurationParser.parse("perm").isEmpty());
    }

    @Test
    void rejectsInvalidOrDangerousDurations() {
        assertThrows(IllegalArgumentException.class, () -> DurationParser.parse("0d"));
        assertThrows(IllegalArgumentException.class, () -> DurationParser.parse("forever"));
        assertThrows(IllegalArgumentException.class, () -> DurationParser.parse("9999999999999999999d"));
        assertFalse(DurationParser.looksLikeDuration("griefing"));
        assertTrue(DurationParser.looksLikeDuration("7d"));
    }
}
