package dev.bloodline.staff.data;

import dev.bloodline.staff.model.CaseStatus;
import dev.bloodline.staff.model.CaseType;
import dev.bloodline.staff.model.ModerationCase;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.CompletionException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class CaseRepositoryTest {
    @TempDir
    Path temporaryDirectory;

    @Test
    void persistsRevokesAndPreventsDuplicateActivePunishments() throws Exception {
        Path file = temporaryDirectory.resolve("moderation.db");
        UUID target = UUID.randomUUID();
        Instant now = Instant.now();
        ModerationCase value = new ModerationCase("BL-20260926-TEST000001", CaseType.BAN, target,
                "PlayerOne", null, "Console", "Testing", now, now.plus(Duration.ofDays(1)),
                CaseStatus.ACTIVE, null, null, null);

        try (CaseRepository repository = new CaseRepository(file)) {
            repository.initialize();
            repository.create(value).join();
            CompletionException duplicate = assertThrows(CompletionException.class, () ->
                    repository.create(new ModerationCase("BL-20260926-TEST000002", CaseType.BAN, target,
                            "PlayerOne", null, "Console", "Duplicate", now, null,
                            CaseStatus.ACTIVE, null, null, null)).join());
            assertInstanceOf(CaseRepository.ActiveCaseException.class, duplicate.getCause());
            assertEquals(1, repository.loadActive(now).join().size());
            assertTrue(repository.revoke(CaseType.BAN, "PlayerOne", "Owner", "Appeal accepted", now).join().isPresent());
        }

        try (CaseRepository reopened = new CaseRepository(file)) {
            reopened.initialize();
            ModerationCase loaded = reopened.byId(value.id()).join().orElseThrow();
            assertEquals(CaseStatus.REVOKED, loaded.status());
            assertEquals("Appeal accepted", loaded.revokeReason());
        }
    }
}
