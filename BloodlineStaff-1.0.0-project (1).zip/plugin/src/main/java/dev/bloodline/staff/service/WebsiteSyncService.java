package dev.bloodline.staff.service;

import com.google.gson.Gson;
import dev.bloodline.staff.data.CaseRepository;
import dev.bloodline.staff.model.ModerationCase;
import org.bukkit.plugin.java.JavaPlugin;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;

public final class WebsiteSyncService {
    private final JavaPlugin plugin;
    private final CaseRepository repository;
    private final Gson gson = new Gson();
    private final AtomicBoolean syncing = new AtomicBoolean();
    private volatile HttpClient client;
    private volatile URI endpoint;
    private volatile String apiKey;
    private volatile Duration requestTimeout;

    public WebsiteSyncService(JavaPlugin plugin, CaseRepository repository) {
        this.plugin = plugin;
        this.repository = repository;
        reload();
    }

    public void reload() {
        String base = plugin.getConfig().getString("website.base-url", "").trim();
        String key = plugin.getConfig().getString("website.api-key", "").trim();
        this.apiKey = key;
        this.requestTimeout = Duration.ofSeconds(Math.max(2, plugin.getConfig().getInt("website.request-timeout-seconds", 8)));
        this.client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(Math.max(2, plugin.getConfig().getInt("website.connect-timeout-seconds", 5))))
                .followRedirects(HttpClient.Redirect.NEVER)
                .build();
        try {
            this.endpoint = base.isBlank() ? null : URI.create(base.replaceAll("/+$", "") + "/api/v1/cases");
        } catch (IllegalArgumentException exception) {
            this.endpoint = null;
            plugin.getLogger().warning("website.base-url is invalid; website sync is disabled.");
        }
    }

    public boolean enabled() {
        return endpoint != null && !apiKey.isBlank() && !apiKey.equals("CHANGE-ME");
    }

    public void syncPending() {
        if (!enabled() || !syncing.compareAndSet(false, true)) return;
        repository.unsynced(50).thenCompose(cases -> {
            CompletableFuture<?>[] futures = cases.stream().map(this::send).toArray(CompletableFuture[]::new);
            return CompletableFuture.allOf(futures);
        }).whenComplete((ignored, error) -> {
            syncing.set(false);
            if (error != null) plugin.getLogger().log(Level.FINE, "Website sync attempt failed; it will retry.", error);
        });
    }

    private CompletableFuture<Void> send(ModerationCase moderationCase) {
        HttpRequest request = HttpRequest.newBuilder(endpoint)
                .timeout(requestTimeout)
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .header("User-Agent", "BloodlineStaff/" + plugin.getPluginMeta().getVersion())
                .POST(HttpRequest.BodyPublishers.ofString(gson.toJson(payload(moderationCase))))
                .build();
        return client.sendAsync(request, HttpResponse.BodyHandlers.discarding()).thenCompose(response -> {
            if (response.statusCode() >= 200 && response.statusCode() < 300) {
                return repository.markSynced(moderationCase.id());
            }
            return CompletableFuture.failedFuture(new IllegalStateException("Website returned HTTP " + response.statusCode()));
        });
    }

    private Map<String, Object> payload(ModerationCase value) {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("id", value.id());
        data.put("type", value.type().name());
        data.put("targetUuid", value.targetUuid().toString());
        data.put("targetName", value.targetName());
        data.put("actorUuid", value.actorUuid() == null ? null : value.actorUuid().toString());
        data.put("actorName", value.actorName());
        data.put("reason", value.reason());
        data.put("createdAt", value.createdAt().toEpochMilli());
        data.put("expiresAt", value.expiresAt() == null ? null : value.expiresAt().toEpochMilli());
        data.put("status", value.status().name());
        data.put("revokedBy", value.revokedBy());
        data.put("revokedAt", value.revokedAt() == null ? null : value.revokedAt().toEpochMilli());
        data.put("revokeReason", value.revokeReason());
        return data;
    }
}
