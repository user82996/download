package dev.bloodline.staff.model;

public enum CaseStatus {
    ACTIVE,
    COMPLETED,
    REVOKED,
    EXPIRED
}
