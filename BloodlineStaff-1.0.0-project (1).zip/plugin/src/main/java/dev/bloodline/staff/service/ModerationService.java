package dev.bloodline.staff.service;

import dev.bloodline.staff.data.CaseRepository;
import dev.bloodline.staff.model.CaseStatus;
import dev.bloodline.staff.model.CaseType;
import dev.bloodline.staff.model.ModerationCase;
import dev.bloodline.staff.util.CaseIdGenerator;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class ModerationService {
    private final CaseRepository repository;
    private final PunishmentCache cache;
    private final WebsiteSyncService website;
    private final CaseIdGenerator ids = new CaseIdGenerator();

    public ModerationService(CaseRepository repository, PunishmentCache cache, WebsiteSyncService website) {
        this.repository = repository;
        this.cache = cache;
        this.website = website;
    }

    public CompletableFuture<ModerationCase> create(
            CaseType type,
            UUID targetUuid,
            String targetName,
            UUID actorUuid,
            String actorName,
            String reason,
            Duration duration) {
        Instant now = Instant.now();
        CaseStatus status = type == CaseType.BAN || type == CaseType.MUTE ? CaseStatus.ACTIVE : CaseStatus.COMPLETED;
        Instant expires = duration == null ? null : now.plus(duration);
        ModerationCase value = new ModerationCase(ids.next(), type, targetUuid, targetName, actorUuid,
                actorName, reason, now, expires, status, null, null, null);
        return repository.create(value).thenApply(ignored -> {
            if (status == CaseStatus.ACTIVE) cache.put(value);
            website.syncPending();
            return value;
        });
    }

    public CompletableFuture<Optional<ModerationCase>> revoke(
            CaseType type, String targetOrId, String actorName, String reason) {
        return repository.revoke(type, targetOrId, actorName, reason, Instant.now()).thenApply(result -> {
            result.ifPresent(cache::remove);
            website.syncPending();
            return result;
        });
    }

    public CompletableFuture<Optional<ModerationCase>> byId(String id) {
        return repository.byId(id);
    }

    public CompletableFuture<List<ModerationCase>> history(String target, int limit) {
        return repository.history(target, limit);
    }

    public CompletableFuture<List<ModerationCase>> staffHistory(String actor, int limit) {
        return repository.staffHistory(actor, limit);
    }

    public void expireDue() {
        repository.expireDue(Instant.now()).thenAccept(expired -> {
            expired.forEach(cache::remove);
            if (!expired.isEmpty()) website.syncPending();
        });
    }
}
