package dev.bloodline.staff.service;

import dev.bloodline.staff.model.ModerationCase;
import dev.bloodline.staff.util.DurationParser;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

public final class MessageService {
    private static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm z");
    private final JavaPlugin plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();

    public MessageService(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void send(CommandSender sender, String key) {
        send(sender, key, Map.of());
    }

    public void send(CommandSender sender, String key, Map<String, String> values) {
        sendComponent(sender, prefixed(key, values));
    }

    public void sendComponent(CommandSender sender, Component message) {
        if (sender instanceof Player player) {
            player.getScheduler().execute(plugin, () -> player.sendMessage(message), null, 1L);
        } else {
            Bukkit.getGlobalRegionScheduler().execute(plugin, () -> sender.sendMessage(message));
        }
    }

    public Component render(String key, Map<String, String> values) {
        return deserialize(plugin.getConfig().getString("messages." + key, "<red>Missing message: " + key), values);
    }

    public Component prefixed(String key, Map<String, String> values) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        String value = plugin.getConfig().getString("messages." + key, "<red>Missing message: " + key);
        return deserialize(prefix + value, values);
    }

    public Map<String, String> values(ModerationCase moderationCase) {
        Instant now = Instant.now();
        ZoneId zone;
        try {
            zone = ZoneId.of(plugin.getConfig().getString("timezone", "UTC"));
        } catch (Exception ignored) {
            zone = ZoneId.of("UTC");
        }
        String expires = moderationCase.expiresAt() == null
                ? "Never (permanent)"
                : DATE_TIME.withZone(zone).format(moderationCase.expiresAt());
        String duration = moderationCase.expiresAt() == null
                ? "permanent"
                : DurationParser.human(Duration.between(now, moderationCase.expiresAt()));
        Map<String, String> values = new LinkedHashMap<>();
        values.put("id", moderationCase.id());
        values.put("type", moderationCase.type().name().toLowerCase());
        values.put("player", moderationCase.targetName());
        values.put("staff", moderationCase.actorName());
        values.put("reason", moderationCase.reason());
        values.put("expires", expires);
        values.put("duration", duration);
        values.put("status", moderationCase.status().name().toLowerCase());
        values.put("appeal", plugin.getConfig().getString("appeal-url", ""));
        return values;
    }

    public void staffNotify(ModerationCase moderationCase) {
        if (!plugin.getConfig().getBoolean("broadcast-punishments", true)) return;
        Component message = render("staff-notify", values(moderationCase));
        Bukkit.getGlobalRegionScheduler().execute(plugin, () -> {
            Bukkit.getConsoleSender().sendMessage(message);
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (!player.hasPermission("bloodlinestaff.notify")) continue;
                player.getScheduler().execute(plugin, () -> player.sendMessage(message), null, 1L);
            }
        });
    }

    private Component deserialize(String template, Map<String, String> values) {
        TagResolver.Builder resolver = TagResolver.builder();
        Map<String, String> all = new LinkedHashMap<>(values);
        all.putIfAbsent("appeal", plugin.getConfig().getString("appeal-url", ""));
        for (Map.Entry<String, String> entry : all.entrySet()) {
            resolver.resolver(Placeholder.unparsed(entry.getKey(), entry.getValue() == null ? "" : entry.getValue()));
        }
        return miniMessage.deserialize(template, resolver.build());
    }
}
