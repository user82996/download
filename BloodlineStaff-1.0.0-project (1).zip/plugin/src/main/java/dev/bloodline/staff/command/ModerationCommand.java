package dev.bloodline.staff.command;

import dev.bloodline.staff.BloodlineStaffPlugin;
import dev.bloodline.staff.data.CaseRepository;
import dev.bloodline.staff.model.CaseType;
import dev.bloodline.staff.model.ModerationCase;
import dev.bloodline.staff.service.MessageService;
import dev.bloodline.staff.service.ModerationService;
import dev.bloodline.staff.util.DurationParser;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletionException;
import java.util.logging.Level;

public final class ModerationCommand implements CommandExecutor, TabCompleter {
    private static final List<String> DURATIONS = List.of("30m", "1h", "12h", "1d", "3d", "7d", "30d");
    private final BloodlineStaffPlugin plugin;
    private final ModerationService moderation;
    private final MessageService messages;

    public ModerationCommand(BloodlineStaffPlugin plugin, ModerationService moderation, MessageService messages) {
        this.plugin = plugin;
        this.moderation = moderation;
        this.messages = messages;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        String permission = command.getPermission();
        if (permission != null && !sender.hasPermission(permission)) {
            messages.send(sender, "no-permission");
            return true;
        }
        return switch (name) {
            case "ban" -> punish(sender, args, CaseType.BAN, false, "usage-ban");
            case "tempban" -> punish(sender, args, CaseType.BAN, true, "usage-tempban");
            case "mute" -> punish(sender, args, CaseType.MUTE, false, "usage-mute");
            case "tempmute" -> punish(sender, args, CaseType.MUTE, true, "usage-tempmute");
            case "kick" -> simple(sender, args, CaseType.KICK, "usage-kick");
            case "warn" -> simple(sender, args, CaseType.WARN, "usage-warn");
            case "unban" -> revoke(sender, args, CaseType.BAN, "usage-unban");
            case "unmute" -> revoke(sender, args, CaseType.MUTE, "usage-unmute");
            case "history" -> history(sender, args, false, "usage-history");
            case "staffhistory" -> history(sender, args, true, "usage-staffhistory");
            case "baninfo" -> info(sender, args);
            case "staffreload" -> reload(sender);
            default -> false;
        };
    }

    private boolean punish(CommandSender sender, String[] args, CaseType type, boolean durationRequired, String usage) {
        int minimum = durationRequired ? 3 : 2;
        if (args.length < minimum) {
            messages.send(sender, usage);
            return true;
        }
        Target target = resolve(args[0]);
        if (target == null) {
            messages.send(sender, "player-not-found");
            return true;
        }
        if (!canPunish(sender, target, type)) return true;

        Duration duration = null;
        int reasonStart = 1;
        if (durationRequired || DurationParser.looksLikeDuration(args[1])) {
            try {
                duration = DurationParser.parse(args[1]).orElse(null);
                if (durationRequired && duration == null) throw new IllegalArgumentException("Permanent temp punishment");
            } catch (IllegalArgumentException exception) {
                messages.send(sender, "invalid-duration");
                return true;
            }
            reasonStart = 2;
        }
        if (reasonStart >= args.length) {
            messages.send(sender, usage);
            return true;
        }
        String reason = cleanReason(join(args, reasonStart));
        if (!validReason(sender, reason)) return true;
        create(sender, target, type, reason, duration);
        return true;
    }

    private boolean simple(CommandSender sender, String[] args, CaseType type, String usage) {
        if (args.length < 2) {
            messages.send(sender, usage);
            return true;
        }
        Target target = resolve(args[0]);
        if (target == null || target.online() == null) {
            messages.send(sender, "player-not-found");
            return true;
        }
        if (!canPunish(sender, target, type)) return true;
        String reason = cleanReason(join(args, 1));
        if (!validReason(sender, reason)) return true;
        create(sender, target, type, reason, null);
        return true;
    }

    private void create(CommandSender sender, Target target, CaseType type, String reason, Duration duration) {
        UUID actorUuid = sender instanceof Player player ? player.getUniqueId() : null;
        moderation.create(type, target.uuid(), target.name(), actorUuid, sender.getName(), reason, duration)
                .whenComplete((moderationCase, error) -> {
                    if (error != null) {
                        Throwable root = unwrap(error);
                        if (root instanceof CaseRepository.ActiveCaseException) {
                            messages.send(sender, "active-case", Map.of("type", type.name().toLowerCase(Locale.ROOT)));
                        } else {
                            plugin.getLogger().log(Level.SEVERE, "Could not create moderation case", root);
                            messages.send(sender, "database-error");
                        }
                        return;
                    }
                    messages.staffNotify(moderationCase);
                    switch (type) {
                        case BAN -> {
                            messages.send(sender, "ban-success", messages.values(moderationCase));
                            kick(target.online(), messages.render("ban-screen", messages.values(moderationCase)));
                        }
                        case MUTE -> {
                            messages.send(sender, "mute-success", messages.values(moderationCase));
                            if (target.online() != null) messages.send(target.online(), "muted", messages.values(moderationCase));
                        }
                        case KICK -> {
                            messages.send(sender, "kick-success", messages.values(moderationCase));
                            kick(target.online(), messages.render("kick-screen", messages.values(moderationCase)));
                        }
                        case WARN -> {
                            messages.send(sender, "warn-success", messages.values(moderationCase));
                            if (target.online() != null) {
                                Component warning = messages.render("warning", messages.values(moderationCase));
                                target.online().getScheduler().execute(plugin, () -> target.online().sendMessage(warning), null, 1L);
                            }
                        }
                    }
                });
    }

    private boolean revoke(CommandSender sender, String[] args, CaseType type, String usage) {
        if (args.length < 1) {
            messages.send(sender, usage);
            return true;
        }
        String reason = args.length > 1 ? cleanReason(join(args, 1)) : "Revoked by staff";
        if (!validReason(sender, reason)) return true;
        moderation.revoke(type, args[0], sender.getName(), reason).whenComplete((result, error) -> {
            if (error != null) {
                plugin.getLogger().log(Level.SEVERE, "Could not revoke moderation case", unwrap(error));
                messages.send(sender, "database-error");
                return;
            }
            if (result.isEmpty()) {
                messages.send(sender, "no-active-case", Map.of("type", type.name().toLowerCase(Locale.ROOT)));
                return;
            }
            ModerationCase value = result.get();
            messages.send(sender, "revoke-success", messages.values(value));
            messages.staffNotify(value);
        });
        return true;
    }

    private boolean history(CommandSender sender, String[] args, boolean staff, String usage) {
        if (args.length != 1) {
            messages.send(sender, usage);
            return true;
        }
        int limit = Math.max(1, Math.min(25, plugin.getConfig().getInt("history-limit", 10)));
        var future = staff ? moderation.staffHistory(args[0], limit) : moderation.history(args[0], limit);
        future.whenComplete((cases, error) -> {
            if (error != null) {
                messages.send(sender, "database-error");
                return;
            }
            Component output = Component.text(staff ? "Staff history: " : "Player history: ", NamedTextColor.DARK_RED)
                    .append(Component.text(args[0] + "\n", NamedTextColor.WHITE));
            if (cases.isEmpty()) output = output.append(Component.text("No cases found.", NamedTextColor.GRAY));
            for (ModerationCase value : cases) {
                output = output.append(Component.text(value.id() + " | ", NamedTextColor.YELLOW))
                        .append(Component.text(value.type().name() + " | " + value.status().name() + " | ", NamedTextColor.GRAY))
                        .append(Component.text(value.targetName() + " | " + value.reason() + "\n", NamedTextColor.WHITE));
            }
            messages.sendComponent(sender, output);
        });
        return true;
    }

    private boolean info(CommandSender sender, String[] args) {
        if (args.length != 1) {
            messages.send(sender, "usage-baninfo");
            return true;
        }
        moderation.byId(args[0]).whenComplete((result, error) -> {
            if (error != null) {
                messages.send(sender, "database-error");
                return;
            }
            if (result.isEmpty()) {
                messages.sendComponent(sender, Component.text("No case found with that ID.", NamedTextColor.RED));
                return;
            }
            ModerationCase value = result.get();
            String expires = value.expiresAt() == null ? "Permanent" : value.expiresAt().toString();
            Component output = Component.text("Bloodline case " + value.id() + "\n", NamedTextColor.DARK_RED)
                    .append(Component.text("Type: " + value.type() + " | Status: " + value.status() + "\n", NamedTextColor.GRAY))
                    .append(Component.text("Player: " + value.targetName() + "\n", NamedTextColor.WHITE))
                    .append(Component.text("Staff: " + value.actorName() + "\n", NamedTextColor.WHITE))
                    .append(Component.text("Reason: " + value.reason() + "\n", NamedTextColor.WHITE))
                    .append(Component.text("Expires: " + expires, NamedTextColor.GRAY));
            messages.sendComponent(sender, output);
        });
        return true;
    }

    private boolean reload(CommandSender sender) {
        plugin.reloadPluginConfiguration();
        messages.sendComponent(sender, Component.text("BloodlineStaff configuration reloaded.", NamedTextColor.GREEN));
        return true;
    }

    private Target resolve(String input) {
        Player online = Bukkit.getPlayerExact(input);
        if (online != null) return new Target(online.getUniqueId(), online.getName(), online, online.isOp());
        OfflinePlayer offline = Bukkit.getOfflinePlayerIfCached(input);
        if (offline == null || (!offline.hasPlayedBefore() && !offline.isOnline())) return null;
        String name = offline.getName();
        return name == null ? null : new Target(offline.getUniqueId(), name, offline.getPlayer(), offline.isOp());
    }

    private boolean canPunish(CommandSender sender, Target target, CaseType type) {
        if (sender instanceof Player player && player.getUniqueId().equals(target.uuid())) {
            messages.send(sender, "protected-player");
            return false;
        }
        boolean namedProtected = plugin.getConfig().getStringList("protected-players").stream()
                .anyMatch(name -> name.equalsIgnoreCase(target.name()));
        if ((target.operator() && plugin.getConfig().getBoolean("protect-operators", true) || namedProtected)
                && !sender.hasPermission("bloodlinestaff.override.protected")) {
            messages.send(sender, "protected-player");
            return false;
        }
        String permission = switch (type) {
            case BAN -> "bloodlinestaff.bypass.ban";
            case KICK -> "bloodlinestaff.bypass.kick";
            case MUTE, WARN -> null;
        };
        if (permission != null && target.online() != null && target.online().hasPermission(permission)) {
            messages.send(sender, "protected-player");
            return false;
        }
        return true;
    }

    private boolean validReason(CommandSender sender, String reason) {
        int maximum = Math.max(20, plugin.getConfig().getInt("max-reason-length", 180));
        if (reason.isBlank()) return false;
        if (reason.length() <= maximum) return true;
        messages.send(sender, "reason-too-long", Map.of("max", Integer.toString(maximum)));
        return false;
    }

    private String cleanReason(String reason) {
        return reason.replaceAll("[\\p{Cc}&&[^\\t]]", "").trim();
    }

    private void kick(Player player, Component reason) {
        if (player == null) return;
        player.getScheduler().execute(plugin, () -> player.kick(reason), null, 1L);
    }

    private static String join(String[] args, int start) {
        return String.join(" ", Arrays.copyOfRange(args, start, args.length));
    }

    private static Throwable unwrap(Throwable error) {
        Throwable value = error;
        while ((value instanceof CompletionException) && value.getCause() != null) value = value.getCause();
        return value;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            List<String> names = new ArrayList<>();
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) names.add(player.getName());
            }
            return names;
        }
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (args.length == 2 && (name.equals("tempban") || name.equals("tempmute") || name.equals("ban") || name.equals("mute"))) {
            return DURATIONS.stream().filter(value -> value.startsWith(args[1].toLowerCase(Locale.ROOT))).toList();
        }
        return List.of();
    }

    private record Target(UUID uuid, String name, Player online, boolean operator) {
    }
}
