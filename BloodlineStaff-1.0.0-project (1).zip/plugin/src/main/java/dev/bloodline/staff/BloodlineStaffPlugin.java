package dev.bloodline.staff;

import dev.bloodline.staff.command.ModerationCommand;
import dev.bloodline.staff.data.CaseRepository;
import dev.bloodline.staff.listener.PunishmentListener;
import dev.bloodline.staff.service.MessageService;
import dev.bloodline.staff.service.ModerationService;
import dev.bloodline.staff.service.PunishmentCache;
import dev.bloodline.staff.service.WebsiteSyncService;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.nio.file.Files;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

public final class BloodlineStaffPlugin extends JavaPlugin {
    private CaseRepository repository;
    private WebsiteSyncService website;
    private PunishmentListener listener;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        try {
            Files.createDirectories(getDataFolder().toPath());
            repository = new CaseRepository(getDataFolder().toPath().resolve("moderation.db"));
            repository.initialize();
        } catch (Exception exception) {
            getLogger().log(Level.SEVERE, "Could not initialize BloodlineStaff database. No punishments were applied.", exception);
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        PunishmentCache cache = new PunishmentCache();
        try {
            cache.load(repository.loadActive(Instant.now()).join());
        } catch (RuntimeException exception) {
            getLogger().log(Level.SEVERE, "Could not load active punishments.", exception);
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        MessageService messages = new MessageService(this);
        website = new WebsiteSyncService(this, repository);
        ModerationService moderation = new ModerationService(repository, cache, website);
        listener = new PunishmentListener(this, cache, messages);
        Bukkit.getPluginManager().registerEvents(listener, this);

        ModerationCommand executor = new ModerationCommand(this, moderation, messages);
        for (String name : List.of("ban", "tempban", "unban", "kick", "mute", "tempmute", "unmute",
                "warn", "history", "staffhistory", "baninfo", "staffreload")) {
            PluginCommand command = getCommand(name);
            if (command == null) throw new IllegalStateException("Command missing from plugin.yml: " + name);
            command.setExecutor(executor);
            command.setTabCompleter(executor);
        }

        Bukkit.getAsyncScheduler().runAtFixedRate(this, task -> moderation.expireDue(), 10, 10, TimeUnit.SECONDS);
        long retry = Math.max(10, getConfig().getLong("website.retry-seconds", 30));
        Bukkit.getAsyncScheduler().runAtFixedRate(this, task -> website.syncPending(), 2, retry, TimeUnit.SECONDS);
        getLogger().info("BloodlineStaff enabled with Folia-safe scheduling and atomic local persistence.");
    }

    public void reloadPluginConfiguration() {
        reloadConfig();
        if (website != null) website.reload();
        if (listener != null) listener.reload();
    }

    @Override
    public void onDisable() {
        Bukkit.getAsyncScheduler().cancelTasks(this);
        Bukkit.getGlobalRegionScheduler().cancelTasks(this);
        if (repository != null) repository.close();
    }

}
