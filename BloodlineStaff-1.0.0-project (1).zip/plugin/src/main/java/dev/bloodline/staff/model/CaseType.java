package dev.bloodline.staff.model;

public enum CaseType {
    BAN,
    MUTE,
    KICK,
    WARN
}
