package dev.bloodline.staff.util;

import java.time.Duration;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class DurationParser {
    private static final Pattern PART = Pattern.compile("(\\d+)([smhdwMy])");
    private static final long MAX_SECONDS = Duration.ofDays(3650).toSeconds();

    private DurationParser() {
    }

    public static boolean looksLikeDuration(String input) {
        String value = input.trim();
        return value.equalsIgnoreCase("perm") || value.equalsIgnoreCase("permanent") || PART.matcher(value).matches();
    }

    public static Optional<Duration> parse(String input) {
        String value = input.trim();
        if (value.equalsIgnoreCase("perm") || value.equalsIgnoreCase("permanent")) {
            return Optional.empty();
        }
        Matcher matcher = PART.matcher(value);
        if (!matcher.matches()) {
            throw new IllegalArgumentException("Invalid duration: " + input);
        }
        long amount;
        try {
            amount = Long.parseLong(matcher.group(1));
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException("Duration is too large", exception);
        }
        if (amount <= 0) {
            throw new IllegalArgumentException("Duration must be positive");
        }
        long multiplier = switch (matcher.group(2)) {
            case "s" -> 1L;
            case "m" -> 60L;
            case "h" -> 3_600L;
            case "d" -> 86_400L;
            case "w" -> 604_800L;
            case "M" -> 2_592_000L;
            case "y" -> 31_536_000L;
            default -> throw new IllegalArgumentException("Invalid duration unit");
        };
        long seconds;
        try {
            seconds = Math.multiplyExact(amount, multiplier);
        } catch (ArithmeticException exception) {
            throw new IllegalArgumentException("Duration is too large", exception);
        }
        if (seconds > MAX_SECONDS) {
            throw new IllegalArgumentException("Duration exceeds 10 years");
        }
        return Optional.of(Duration.ofSeconds(seconds));
    }

    public static String human(Duration duration) {
        long seconds = Math.max(0, duration.getSeconds());
        long days = seconds / 86_400;
        long hours = seconds % 86_400 / 3_600;
        long minutes = seconds % 3_600 / 60;
        long secs = seconds % 60;
        StringBuilder result = new StringBuilder();
        append(result, days, "d");
        append(result, hours, "h");
        append(result, minutes, "m");
        if (result.isEmpty()) append(result, secs, "s");
        return result.toString().trim().toLowerCase(Locale.ROOT);
    }

    private static void append(StringBuilder result, long amount, String unit) {
        if (amount > 0 && result.length() < 12) result.append(amount).append(unit).append(' ');
    }
}
