package dev.bloodline.staff.listener;

import dev.bloodline.staff.model.ModerationCase;
import dev.bloodline.staff.service.MessageService;
import dev.bloodline.staff.service.PunishmentCache;
import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Instant;
import java.util.HashSet;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;

public final class PunishmentListener implements Listener {
    private final JavaPlugin plugin;
    private final PunishmentCache cache;
    private final MessageService messages;
    private volatile Set<String> blockedCommands = Set.of();

    public PunishmentListener(JavaPlugin plugin, PunishmentCache cache, MessageService messages) {
        this.plugin = plugin;
        this.cache = cache;
        this.messages = messages;
        reload();
    }

    public void reload() {
        Set<String> commands = new HashSet<>();
        for (String value : plugin.getConfig().getStringList("mute.blocked-commands")) {
            commands.add(value.toLowerCase(Locale.ROOT).replaceFirst("^/", ""));
        }
        blockedCommands = Set.copyOf(commands);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPreLogin(AsyncPlayerPreLoginEvent event) {
        cache.ban(event.getUniqueId(), Instant.now()).ifPresent(moderationCase -> event.disallow(
                AsyncPlayerPreLoginEvent.Result.KICK_BANNED,
                messages.render("ban-screen", messages.values(moderationCase))
        ));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        if (event.getPlayer().hasPermission("bloodlinestaff.bypass.mute")) return;
        Optional<ModerationCase> muted = cache.mute(event.getPlayer().getUniqueId(), Instant.now());
        if (muted.isEmpty()) return;
        event.setCancelled(true);
        messages.send(event.getPlayer(), "muted", messages.values(muted.get()));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (event.getPlayer().hasPermission("bloodlinestaff.bypass.mute")) return;
        String content = event.getMessage().substring(1);
        String label = content.split(" ", 2)[0].toLowerCase(Locale.ROOT);
        if (!blockedCommands.contains(label)) return;
        cache.mute(event.getPlayer().getUniqueId(), Instant.now()).ifPresent(moderationCase -> {
            event.setCancelled(true);
            messages.send(event.getPlayer(), "muted", messages.values(moderationCase));
        });
    }
}
