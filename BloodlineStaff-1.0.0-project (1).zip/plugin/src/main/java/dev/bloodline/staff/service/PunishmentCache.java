package dev.bloodline.staff.service;

import dev.bloodline.staff.model.CaseType;
import dev.bloodline.staff.model.ModerationCase;

import java.time.Instant;
import java.util.Collection;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PunishmentCache {
    private final ConcurrentHashMap<UUID, ModerationCase> bans = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<UUID, ModerationCase> mutes = new ConcurrentHashMap<>();

    public void load(Collection<ModerationCase> cases) {
        bans.clear();
        mutes.clear();
        cases.forEach(this::put);
    }

    public void put(ModerationCase moderationCase) {
        if (moderationCase.type() == CaseType.BAN) bans.put(moderationCase.targetUuid(), moderationCase);
        if (moderationCase.type() == CaseType.MUTE) mutes.put(moderationCase.targetUuid(), moderationCase);
    }

    public Optional<ModerationCase> ban(UUID uuid, Instant now) {
        return active(bans, uuid, now);
    }

    public Optional<ModerationCase> mute(UUID uuid, Instant now) {
        return active(mutes, uuid, now);
    }

    public void remove(ModerationCase moderationCase) {
        map(moderationCase.type()).remove(moderationCase.targetUuid(), moderationCase);
    }

    private Optional<ModerationCase> active(ConcurrentHashMap<UUID, ModerationCase> map, UUID uuid, Instant now) {
        ModerationCase value = map.get(uuid);
        if (value == null) return Optional.empty();
        if (!value.isActiveAt(now)) {
            map.remove(uuid, value);
            return Optional.empty();
        }
        return Optional.of(value);
    }

    private ConcurrentHashMap<UUID, ModerationCase> map(CaseType type) {
        return type == CaseType.BAN ? bans : mutes;
    }
}
