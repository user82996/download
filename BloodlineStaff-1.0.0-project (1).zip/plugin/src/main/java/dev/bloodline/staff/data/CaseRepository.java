package dev.bloodline.staff.data;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import dev.bloodline.staff.model.CaseStatus;
import dev.bloodline.staff.model.CaseType;
import dev.bloodline.staff.model.ModerationCase;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Atomic JSON storage. Every mutation is forced to a temporary file before it atomically
 * replaces the previous snapshot. All access is serialized on one dedicated I/O thread.
 */
public final class CaseRepository implements AutoCloseable {
    private static final Type STORED_LIST = new TypeToken<List<StoredCase>>() { }.getType();
    private final Path path;
    private final Path temporaryPath;
    private final Path backupPath;
    private final Gson gson = new Gson();
    private final Map<String, StoredCase> cases = new LinkedHashMap<>();
    private final ExecutorService executor = Executors.newSingleThreadExecutor(runnable -> {
        Thread thread = new Thread(runnable, "BloodlineStaff-Database");
        thread.setDaemon(true);
        return thread;
    });

    public CaseRepository(Path databasePath) {
        String filename = databasePath.getFileName().toString().replaceFirst("\\.db$", ".json");
        this.path = databasePath.resolveSibling(filename);
        this.temporaryPath = path.resolveSibling(path.getFileName() + ".tmp");
        this.backupPath = path.resolveSibling(path.getFileName() + ".bak");
    }

    public void initialize() throws IOException {
        Files.createDirectories(path.getParent());
        if (!Files.exists(path)) {
            writeSnapshot();
            return;
        }
        try {
            load(path);
        } catch (IOException | JsonParseException exception) {
            if (!Files.exists(backupPath)) throw exception;
            cases.clear();
            load(backupPath);
            writeSnapshot();
        }
    }

    public CompletableFuture<Void> create(ModerationCase value) {
        return run(() -> {
            Instant now = Instant.now();
            if (value.type() == CaseType.BAN || value.type() == CaseType.MUTE) {
                for (StoredCase stored : List.copyOf(cases.values())) {
                    ModerationCase existing = stored.toModel();
                    if (existing.type() != value.type() || !existing.targetUuid().equals(value.targetUuid())) continue;
                    if (existing.status() != CaseStatus.ACTIVE) continue;
                    if (existing.expiresAt() != null && !existing.expiresAt().isAfter(now)) {
                        cases.put(existing.id(), StoredCase.from(existing.withStatus(CaseStatus.EXPIRED, null, null, null), false));
                    } else {
                        throw new ActiveCaseException();
                    }
                }
            }
            if (cases.containsKey(value.id())) throw new RepositoryException("Duplicate case ID");
            cases.put(value.id(), StoredCase.from(value, false));
            writeSnapshot();
            return null;
        });
    }

    public CompletableFuture<Optional<ModerationCase>> byId(String id) {
        return run(() -> Optional.ofNullable(cases.get(id.toUpperCase(Locale.ROOT))).map(StoredCase::toModel));
    }

    public CompletableFuture<List<ModerationCase>> loadActive(Instant now) {
        return run(() -> cases.values().stream().map(StoredCase::toModel)
                .filter(value -> (value.type() == CaseType.BAN || value.type() == CaseType.MUTE) && value.isActiveAt(now))
                .sorted(Comparator.comparing(ModerationCase::createdAt))
                .toList());
    }

    public CompletableFuture<List<ModerationCase>> history(String target, int limit) {
        return run(() -> cases.values().stream().map(StoredCase::toModel)
                .filter(value -> value.targetName().equalsIgnoreCase(target) || value.targetUuid().toString().equalsIgnoreCase(target))
                .sorted(Comparator.comparing(ModerationCase::createdAt).reversed())
                .limit(limit)
                .toList());
    }

    public CompletableFuture<List<ModerationCase>> staffHistory(String actor, int limit) {
        return run(() -> cases.values().stream().map(StoredCase::toModel)
                .filter(value -> value.actorName().equalsIgnoreCase(actor)
                        || value.actorUuid() != null && value.actorUuid().toString().equalsIgnoreCase(actor))
                .sorted(Comparator.comparing(ModerationCase::createdAt).reversed())
                .limit(limit)
                .toList());
    }

    public CompletableFuture<Optional<ModerationCase>> revoke(
            CaseType type, String targetOrId, String revokedBy, String reason, Instant now) {
        return run(() -> {
            Optional<ModerationCase> found = cases.values().stream().map(StoredCase::toModel)
                    .filter(value -> value.type() == type && value.isActiveAt(now))
                    .filter(value -> value.id().equalsIgnoreCase(targetOrId)
                            || value.targetName().equalsIgnoreCase(targetOrId)
                            || value.targetUuid().toString().equalsIgnoreCase(targetOrId))
                    .max(Comparator.comparing(ModerationCase::createdAt));
            if (found.isEmpty()) return Optional.empty();
            ModerationCase revoked = found.get().withStatus(CaseStatus.REVOKED, revokedBy, now, reason);
            cases.put(revoked.id(), StoredCase.from(revoked, false));
            writeSnapshot();
            return Optional.of(revoked);
        });
    }

    public CompletableFuture<List<ModerationCase>> expireDue(Instant now) {
        return run(() -> {
            List<ModerationCase> expired = new ArrayList<>();
            for (StoredCase stored : List.copyOf(cases.values())) {
                ModerationCase value = stored.toModel();
                if (value.status() != CaseStatus.ACTIVE || value.expiresAt() == null || value.expiresAt().isAfter(now)) continue;
                ModerationCase updated = value.withStatus(CaseStatus.EXPIRED, null, null, null);
                cases.put(updated.id(), StoredCase.from(updated, false));
                expired.add(updated);
            }
            if (!expired.isEmpty()) writeSnapshot();
            return List.copyOf(expired);
        });
    }

    public CompletableFuture<List<ModerationCase>> unsynced(int limit) {
        return run(() -> cases.values().stream().filter(value -> !value.synced()).map(StoredCase::toModel)
                .sorted(Comparator.comparing(ModerationCase::createdAt))
                .limit(limit)
                .toList());
    }

    public CompletableFuture<Void> markSynced(String id) {
        return run(() -> {
            StoredCase value = cases.get(id);
            if (value != null && !value.synced()) {
                cases.put(id, value.withSynced(true));
                writeSnapshot();
            }
            return null;
        });
    }

    private void load(Path source) throws IOException {
        String json = Files.readString(source, StandardCharsets.UTF_8);
        List<StoredCase> stored = gson.fromJson(json, STORED_LIST);
        if (stored == null) return;
        for (StoredCase value : stored) {
            value.validate();
            cases.put(value.id(), value);
        }
    }

    private void writeSnapshot() throws IOException {
        byte[] data = gson.toJson(new ArrayList<>(cases.values()), STORED_LIST).getBytes(StandardCharsets.UTF_8);
        try (FileChannel channel = FileChannel.open(temporaryPath, StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
            ByteBuffer buffer = ByteBuffer.wrap(data);
            while (buffer.hasRemaining()) channel.write(buffer);
            channel.force(true);
        }
        if (Files.exists(path)) Files.copy(path, backupPath, StandardCopyOption.REPLACE_EXISTING);
        try {
            Files.move(temporaryPath, path, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException exception) {
            Files.move(temporaryPath, path, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private <T> CompletableFuture<T> run(IoSupplier<T> action) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                return action.get();
            } catch (IOException exception) {
                throw new RepositoryException(exception);
            }
        }, executor);
    }

    @Override
    public void close() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) executor.shutdownNow();
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            executor.shutdownNow();
        }
    }

    @FunctionalInterface
    private interface IoSupplier<T> {
        T get() throws IOException;
    }

    private record StoredCase(
            String id, String type, String targetUuid, String targetName, String actorUuid, String actorName,
            String reason, long createdAt, Long expiresAt, String status, String revokedBy, Long revokedAt,
            String revokeReason, boolean synced) {
        static StoredCase from(ModerationCase value, boolean synced) {
            return new StoredCase(value.id(), value.type().name(), value.targetUuid().toString(), value.targetName(),
                    value.actorUuid() == null ? null : value.actorUuid().toString(), value.actorName(), value.reason(),
                    value.createdAt().toEpochMilli(), value.expiresAt() == null ? null : value.expiresAt().toEpochMilli(),
                    value.status().name(), value.revokedBy(), value.revokedAt() == null ? null : value.revokedAt().toEpochMilli(),
                    value.revokeReason(), synced);
        }

        ModerationCase toModel() {
            return new ModerationCase(id, CaseType.valueOf(type), UUID.fromString(targetUuid), targetName,
                    actorUuid == null ? null : UUID.fromString(actorUuid), actorName, reason, Instant.ofEpochMilli(createdAt),
                    expiresAt == null ? null : Instant.ofEpochMilli(expiresAt), CaseStatus.valueOf(status), revokedBy,
                    revokedAt == null ? null : Instant.ofEpochMilli(revokedAt), revokeReason);
        }

        StoredCase withSynced(boolean value) {
            return new StoredCase(id, type, targetUuid, targetName, actorUuid, actorName, reason, createdAt,
                    expiresAt, status, revokedBy, revokedAt, revokeReason, value);
        }

        void validate() throws IOException {
            try {
                toModel();
            } catch (RuntimeException exception) {
                throw new IOException("Invalid moderation data in " + id, exception);
            }
        }
    }

    public static class RepositoryException extends RuntimeException {
        private static final long serialVersionUID = 1L;

        public RepositoryException(String message) {
            super(message);
        }

        public RepositoryException(IOException cause) {
            super(cause);
        }
    }

    public static final class ActiveCaseException extends RepositoryException {
        private static final long serialVersionUID = 1L;

        public ActiveCaseException() {
            super("Target already has an active punishment of this type");
        }
    }
}
