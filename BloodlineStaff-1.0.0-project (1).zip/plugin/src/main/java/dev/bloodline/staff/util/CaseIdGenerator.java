package dev.bloodline.staff.util;

import java.security.SecureRandom;
import java.time.Clock;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

public final class CaseIdGenerator {
    private static final char[] ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ".toCharArray();
    private static final DateTimeFormatter DATE = DateTimeFormatter.BASIC_ISO_DATE;
    private final SecureRandom random;
    private final Clock clock;

    public CaseIdGenerator() {
        this(new SecureRandom(), Clock.systemUTC());
    }

    CaseIdGenerator(SecureRandom random, Clock clock) {
        this.random = random;
        this.clock = clock;
    }

    public String next() {
        StringBuilder suffix = new StringBuilder(10);
        for (int i = 0; i < 10; i++) suffix.append(ALPHABET[random.nextInt(ALPHABET.length)]);
        return "BL-" + LocalDate.now(clock.withZone(ZoneOffset.UTC)).format(DATE) + "-" + suffix;
    }
}
