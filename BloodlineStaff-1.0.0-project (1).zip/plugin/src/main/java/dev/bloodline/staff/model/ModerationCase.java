package dev.bloodline.staff.model;

import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

public record ModerationCase(
        String id,
        CaseType type,
        UUID targetUuid,
        String targetName,
        UUID actorUuid,
        String actorName,
        String reason,
        Instant createdAt,
        Instant expiresAt,
        CaseStatus status,
        String revokedBy,
        Instant revokedAt,
        String revokeReason
) {
    public ModerationCase {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(targetUuid, "targetUuid");
        Objects.requireNonNull(targetName, "targetName");
        Objects.requireNonNull(actorName, "actorName");
        Objects.requireNonNull(reason, "reason");
        Objects.requireNonNull(createdAt, "createdAt");
        Objects.requireNonNull(status, "status");
    }

    public boolean isActiveAt(Instant now) {
        return status == CaseStatus.ACTIVE && (expiresAt == null || expiresAt.isAfter(now));
    }

    public ModerationCase withStatus(CaseStatus newStatus, String by, Instant at, String revocationReason) {
        return new ModerationCase(id, type, targetUuid, targetName, actorUuid, actorName, reason,
                createdAt, expiresAt, newStatus, by, at, revocationReason);
    }
}
