plugins {
    java
}

group = "dev.bloodline"
version = "1.0.0"

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(21))
}

repositories {
    mavenCentral()
}

dependencies {
    compileOnly(files("vendor/paper-api-1.21.11-R0.1-SNAPSHOT.jar"))
    compileOnly(files("vendor/adventure-api-4.26.1.jar"))
    compileOnly(files("vendor/adventure-key-4.26.1.jar"))
    compileOnly(files("vendor/adventure-text-minimessage-4.26.1.jar"))
    compileOnly(files("vendor/annotations-26.0.2.jar"))
    compileOnly(files("vendor/bungeecord-chat-1.21-R0.2-deprecated-build.21.jar"))
    compileOnly(files("vendor/examination-api-1.3.0.jar"))
    compileOnly(files("vendor/examination-string-1.3.0.jar"))
    compileOnly(files("vendor/jspecify-1.0.0.jar"))
    compileOnly(files("vendor/snakeyaml-2.0.jar"))
    compileOnly(files("vendor/guava-33.4.6-jre.jar"))
    implementation(files("vendor/gson-2.13.1.jar"))
    testImplementation(files("vendor/junit-platform-console-standalone-1.13.4.jar"))
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release.set(21)
    options.compilerArgs.add("-Xlint:all")
}

tasks.processResources {
    filesMatching("plugin.yml") {
        expand("version" to project.version)
    }
}

tasks.jar {
    archiveFileName.set("BloodlineStaff-${project.version}.jar")
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
    from(configurations.runtimeClasspath.get().map { if (it.isDirectory) it else zipTree(it) })
    from("../THIRD_PARTY_NOTICES.md")
    exclude("META-INF/*.SF", "META-INF/*.RSA", "META-INF/*.DSA", "META-INF/versions/9/module-info.class")
}

tasks.test {
    useJUnitPlatform()
}
