# BloodlineStaff 1.0.0

BloodlineStaff is a Folia-safe moderation suite for Bloodline SMP. It provides configurable bans, temporary bans, kicks, mutes, temporary mutes, warnings, case history, Ban IDs, offline enforcement, and a matching VPS-hosted website.

Every action gets an ID such as `BL-20260926-AB12CD34EF`. Bans show the ID, expiry, reason, and the Bloodline appeal link: <https://discord.gg/MWJsTKHqgr>.

## What is included

- `BloodlineStaff-1.0.0.jar` — ready-to-install Folia plugin.
- `plugin/` — complete Gradle Java 21 project and tests.
- `website/` — dependency-free Node.js 22 website/API with SQLite storage.
- `deploy/` — Docker Compose and Caddy HTTPS configuration for a VPS.

The plugin always saves a punishment locally before applying it. Website outages cannot lose or bypass punishments: unsynced cases remain queued and retry automatically. Local data is written as an atomic snapshot at `plugins/BloodlineStaff/moderation.json`, with the prior snapshot kept as `moderation.json.bak`.

## Plugin installation

1. Stop the server.
2. Put `BloodlineStaff-1.0.0.jar` in the server's `plugins` folder.
3. Start the server once, then open `plugins/BloodlineStaff/config.yml`.
4. Customize messages if wanted. All message fields use MiniMessage formatting.
5. Restart the server after initial setup. Use `/staffreload` only for later message/API configuration edits.

The target is Folia 1.21.11 and Java 21. Do not use Bukkit `/reload` or PlugMan-style hot loading.

### Commands

| Command | Purpose |
| --- | --- |
| `/ban <player> <reason>` | Permanent ban |
| `/ban <player> <duration> <reason>` | Convenient temporary ban |
| `/tempban <player> <duration> <reason>` | Temporary ban; duration required |
| `/unban <player\|ban-id> [reason]` | Revoke an active ban |
| `/kick <player> <reason>` | Kick and create a case |
| `/mute <player> <reason>` | Permanent mute |
| `/mute <player> <duration> <reason>` | Convenient temporary mute |
| `/tempmute <player> <duration> <reason>` | Temporary mute; duration required |
| `/unmute <player\|case-id> [reason]` | Revoke an active mute |
| `/warn <player> <reason>` | Warn and create a case |
| `/history <player>` | Recent player cases |
| `/staffhistory <staff>` | Recent cases issued by a staff member |
| `/baninfo <id>` | Inspect one case in game |
| `/staffreload` | Reload config and website settings |

Durations support `s`, `m`, `h`, `d`, `w`, `M` (30-day month), and `y`, up to 10 years. Examples: `30m`, `12h`, `7d`, `2w`.

### LuckPerms permissions

For a full moderator role:

```text
/lp group moderator permission set bloodlinestaff.command.ban true
/lp group moderator permission set bloodlinestaff.command.tempban true
/lp group moderator permission set bloodlinestaff.command.unban true
/lp group moderator permission set bloodlinestaff.command.kick true
/lp group moderator permission set bloodlinestaff.command.mute true
/lp group moderator permission set bloodlinestaff.command.tempmute true
/lp group moderator permission set bloodlinestaff.command.unmute true
/lp group moderator permission set bloodlinestaff.command.warn true
/lp group moderator permission set bloodlinestaff.command.history true
/lp group moderator permission set bloodlinestaff.command.staffhistory true
/lp group moderator permission set bloodlinestaff.command.baninfo true
/lp group moderator permission set bloodlinestaff.notify true
```

Owner/admin can receive everything with `bloodlinestaff.admin`. Operators are protected by default, and you can add owner names under `protected-players` in `config.yml`. Only `bloodlinestaff.override.protected` can bypass those protections. Give other online protected players `bloodlinestaff.bypass.ban` or `bloodlinestaff.bypass.kick`. `bloodlinestaff.bypass.mute` lets a player speak while muted.

Because Essentials also has moderation commands, verify `/ban` using `/help ban`. BloodlineStaff loads before Essentials to claim its labels. The explicit commands `/bloodlinestaff:ban`, `/bloodlinestaff:kick`, and the other namespaced forms always select this plugin if another plugin still takes a short command.

## Website installation on a VPS

Requirements: a Linux VPS, Docker with the Compose plugin, a domain/subdomain pointed at the VPS, and inbound TCP ports 80/443 plus UDP 443 open.

```bash
cd BloodlineStaff/deploy
cp .env.example .env
openssl rand -hex 32
openssl rand -hex 32
nano .env
docker compose up -d --build
docker compose logs -f
```

Put the first generated secret in `API_KEY`, the second in `SESSION_SECRET`, set a separate strong `STAFF_PASSWORD`, and change `DOMAIN`. Caddy obtains and renews HTTPS automatically once DNS is correct.

Then configure the Minecraft plugin:

```yaml
website:
  base-url: "https://bans.yourdomain.com"
  api-key: "the-exact-same-API_KEY-from-the-VPS"
  connect-timeout-seconds: 5
  request-timeout-seconds: 8
  retry-seconds: 30
```

Run `/staffreload`. Existing unsynced records will upload automatically. Do not place the API key in the website's public JavaScript, Discord, or screenshots.

The front page provides a safe public case lookup. It only exposes ID, type, player name, staff name, reason, times, and status. UUIDs and API credentials never appear publicly. The staff dashboard uses the password from `.env`, an HMAC-signed `HttpOnly` session cookie, rate-limited login, strict security headers, and server-side search.

### Backups and updates

- Back up the Docker volume `deploy_portal_data` and `plugins/BloodlineStaff/moderation.json`.
- To update the website: replace the website files and run `docker compose up -d --build`.
- To see website health: `curl https://bans.yourdomain.com/health`.
- To stop it: `docker compose down`. Do not add `-v` unless you intentionally want to delete the website database.

## Building and tests

From `plugin/`, run `./gradlew clean test jar` with Java 21. The output is under `plugin/build/libs/`. The website has no npm dependencies; from `website/`, run `npm test`.

Automated checks cover duration parsing, duplicate active punishment protection, persistence/restart recovery, revocation, API-key ingestion, public redaction, login enforcement, staff search access, and status updates.
